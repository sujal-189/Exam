<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

<form method="post" enctype="multipart/form-data">
    <input type="file" name="file" required>
	<br>
    <input type="submit" name="submit" value="Upload">
</form>

<?php
if (isset($_POST['submit'])) {
    if (isset($_FILES['file']) && $_FILES['file']['error'] === 0) {
        if ($_FILES['file']['size'] > 1048576) {
            echo "Error: File size exceeds 1MB.";
        } else {
            move_uploaded_file($_FILES['file']['tmp_name'], "uploads/" . $_FILES['file']['name']);
            echo "File uploaded successfully.";
        }
    } else {
        echo "No file selected or upload error.";
    }
}
?>

</body>
</html>
