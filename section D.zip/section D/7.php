<?php
if(isset($_POST['submit'])){
    echo "<pre>";
    print_r($_FILES);
    echo "</pre>";

    $img = $_FILES['image']['name'];
    $_file = $_FILES['image']['tmp_name']; 

    $_Path = "uploads/".basename($img);

    $move = move_uploaded_file($_file, $_Path);
    if($move){
        echo "File uploaded.";
    } else {
        echo "File is not uploaded.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST" enctype="multipart/form-data">
        <p>
            <label for="">Upload Image</label>
            <br>
            <input type="file" id="image" name="image">
            <br>
            <input type="submit" name="submit" value="submit">
        </p>
    </form>
</body>
</html>