<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

<h2>Contents of data.txt</h2>

<?php
$filename = "data.txt";

if (file_exists($filename)) {
    
    $content = file_get_contents($filename);

    echo nl2br(htmlspecialchars($content)); 
} else {
    echo "The file 'data.txt' does not exist.";
}
?>

</body>
</html>
