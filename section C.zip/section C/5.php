 <?php 

    if(isset($_POST['store'])){
        $content = $_POST['content'];
        echo $content;

        $file   = "data.txt";
        if(is_writable($file)){

            if(!$fp = fopen("data.txt","a")){
                echo "File cannot be open ($file)";
            }

            if(fwrite($fp,$content) === FALSE){
                echo "Cannot write to the file ($file)";
            }

            echo "Success, new ($content ) addded to ($file)";
            fclose($fp);
        }else{
            echo "File is not writable.";
        }
    }   

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Saving your important data</h1>
    <hr>
    <form action="5.php" method="POST">
        <p>
            <label for="content">Content:</label><br>
            <textarea name="content" id="content" rows="8" cols="30" placeholder="Content"></textarea>
        </p>
        <p>
            <input type="submit" value="Store" name="store">
        </p>
    </form>
</body>
</html>