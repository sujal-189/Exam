<?php
$course = "";
$feeMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $course = $_POST["course"] ?? "";

    switch (strtolower($course)) {
        case "php":
            $feeMessage = "The fee for PHP course is Rs 300.";
            break;
        case "python":
            $feeMessage = "The fee for Python course is Rs 350.";
            break;
        case "java":
            $feeMessage = "The fee for Java course is Rs400.";
            break;
        default:
            $feeMessage = "Please select a valid course.";
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Course Fee Calculator</title>
</head>
<body>
    <form method="post" action="">
        <label for="course">Select Course:</label><br>
        <select name="course" id="course">
            <option value="">--Select--</option>
            <option value="PHP" <?= $course == "PHP" ? "selected" : "" ?>>PHP</option>
            <option value="Python" <?= $course == "Python" ? "selected" : "" ?>>Python</option>
            <option value="Java" <?= $course == "Java" ? "selected" : "" ?>>Java</option>
        </select><br><br>

        <input type="submit" value="Get Fee">
    </form>

    <?php if ($feeMessage !== ""): ?>
        <p><?= htmlspecialchars($feeMessage) ?></p>
    <?php endif; ?>
</body>
</html>
