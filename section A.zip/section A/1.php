<?php
$name = "";
$age = "";
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars(trim($_POST["name"] ?? ""));
    $age = intval($_POST["age"] ?? 0);

    if ($name === "" || $age <= 0) {
        $message = "Please enter a valid name and age.";
    } else {
        $message = "Hello, $name! ";

        if ($age < 18) {
            $message .= "You are a minor.";
        } elseif ($age < 60) {
            $message .= "You are an adult.";
        } else {
            $message .= "You are a senior.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Greeting</title>
</head>
<body>
    <form method="post" action="">
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name" value="<?= htmlspecialchars($name) ?>"><br><br>

        <label for="age">Age:</label><br>
        <input type="number" id="age" name="age" value="<?= htmlspecialchars($age) ?>" min="1"><br><br>

        <input type="submit" value="Submit">
    </form>

    <?php if ($message !== ""): ?>
        <p><?= $message ?></p>
    <?php endif; ?>
</body>
</html>

