<?php 

$rankers = [
    "Jayraj" => ["maths" => "50", "hindi" => "65", "gujarati" => "60"],
    "Nirjay" => ["maths" => "60", "hindi" => "55", "gujarati" => "40"],
    "Dev" => ["maths" => "55", "hindi" => "60", "gujarati" => "68"]      
];

if (count($rankers) >= 10) {
 
}

echo $rankers["Jayraj"]["hindi"];

?>
