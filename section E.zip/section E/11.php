<!DOCTYPE html>
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<title>Inner Join</title>
</head>
<body>

<h2>Inner Join</h2>

<?php
$conn = new mysqli("localhost", "root", "", "school");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT students.id, students.name, classes.class_name FROM students INNER JOIN classes ON students.class_id = classes.id";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo '<table class="table table-striped" border="1" cellspacing="0" cellpadding="10px">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Class Name</th>
            </tr>';
    
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['name']}</td>
                <td>{$row['class_name']}</td>
              </tr>";
    }

    echo "</table>";
} else {
    echo "No records found.";
}

$conn->close();
?>

</body>
</html>
