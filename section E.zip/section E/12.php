<?php
$conn = new mysqli("localhost", "root", "", "school");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM students WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<script>alert('Student deleted successfully!');</script>";
        echo "<script>window.location.href='?';</script>";
    } else {
        echo "<script>alert('Error deleting student!');</script>";
    }
    $stmt->close();
}

if (isset($_POST['update'])) {
    $id = intval($_POST['id']);
    $name = $_POST['name'];
    $class_id = intval($_POST['class_id']);

    $stmt = $conn->prepare("UPDATE students SET name = ?, class_id = ? WHERE id = ?");
    $stmt->bind_param("sii", $name, $class_id, $id);

    if ($stmt->execute()) {
        echo "<script>alert('Student updated successfully!');</script>";
        echo "<script>window.location.href='?';</script>";
    } else {
        echo "<script>alert('Error updating student!');</script>";
    }
    $stmt->close();
}

$edit_student = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $edit_student = $result->fetch_assoc();
    $stmt->close();
}

$sql = "SELECT students.id, students.name, students.class_id, classes.class_name 
        FROM students 
        INNER JOIN classes ON students.class_id = classes.id 
        ORDER BY students.id";
$students = $conn->query($sql);

$classes_sql = "SELECT id, class_name FROM classes ORDER BY id";
$classes = $conn->query($classes_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student CRUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        function confirmDelete(id, name) {
            if (confirm("Are you sure you want to delete student: " + name + "?")) {
                window.location.href = "?delete=" + id;
            }
        }

        function confirmUpdate() {
            return confirm("Are you sure you want to update this student's information?");
        }
    </script>
</head>
<body>
<div class="container mt-4">
    <h2>Student Management System</h2>
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Class</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($students->num_rows > 0): ?>
                    <?php while ($row = $students->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['id'] ?></td>
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td><?= htmlspecialchars($row['class_name']) ?></td>
                            <td>
                                <a href="?edit=<?= $row['id'] ?>" class="btn btn-primary btn-sm">Edit</a>
                                <button onclick="confirmDelete(<?= $row['id'] ?>, '<?= htmlspecialchars($row['name']) ?>')" class="btn btn-danger btn-sm">Delete</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="4" class="text-center">No students found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if ($edit_student): ?>
        <div class="card">
            <div class="card-header">Edit Student (ID: <?= $edit_student['id'] ?>)</div>
            <div class="card-body">
                <form method="post" onsubmit="return confirmUpdate();">
                    <input type="hidden" name="id" value="<?= $edit_student['id'] ?>">
                    <div class="mb-3">
                        <label class="form-label">Student Name</label>
                        <input type="text" name="name" class="form-control" required value="<?= htmlspecialchars($edit_student['name']) ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Class</label>
                        <select name="class_id" class="form-control" required>
                            <option value="">Select Class</option>
                            <?php $classes->data_seek(0); while ($class = $classes->fetch_assoc()): ?>
                                <option value="<?= $class['id'] ?>" <?= ($class['id'] == $edit_student['class_id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($class['class_name']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <button type="submit" name="update" class="btn btn-success">Update</button>
                    <a href="?" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php $conn->close(); ?>
