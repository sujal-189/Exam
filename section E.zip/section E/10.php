<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

<h2>Add Student</h2>

<form method="post">
    Name: <input type="text" name="name" required><br><br>
    Class ID: <input type="number" name="class_id" required><br><br>
    <input type="submit" name="submit" value="Add Student">
</form>

<?php

$conn = new mysqli("localhost", "root", "", "school");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $class_id = $_POST['class_id'];

    $sql = "INSERT INTO students (name, class_id) VALUES ('$name', '$class_id')";

    if ($conn->query($sql) === TRUE) {
        echo "<p style='color:green;'>Student added successfully!</p>";
    } else {
        echo "<p style='color:red;'>Error: " . $conn->error . "</p>";
    }
}

$conn->close();
?>

</body>
</html>
